type VoiceConfig = {
  "Name": string,
  "Gender": string,
  "ContentCategories": string[],
  "VoicePersonalities": string[]
}