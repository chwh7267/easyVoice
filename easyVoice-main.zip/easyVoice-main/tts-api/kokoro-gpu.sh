docker run -d --gpus all --restart unless-stopped --name -p 8880:8880 kokoro-api ghcr.io/remsky/kokoro-fastapi-cpu:v0.2.3pre
